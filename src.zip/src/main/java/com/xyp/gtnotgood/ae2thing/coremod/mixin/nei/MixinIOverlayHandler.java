package com.xyp.gtnotgood.ae2thing.coremod.mixin.nei;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

import org.spongepowered.asm.mixin.Mixin;

import com.xyp.gtnotgood.ae2thing.api.AE2ThingAPI;
import com.xyp.gtnotgood.ae2thing.nei.AEItemOverlayState;
import com.xyp.gtnotgood.ae2thing.util.Ae2ReflectClient;
import com.xyp.gtnotgood.ae2thing.util.Util;
import com.xyp.gtnotgood.common.compat.FluidDropCompat;

import appeng.api.config.FuzzyMode;
import appeng.api.storage.data.IAEItemStack;
import appeng.api.storage.data.IAEStack;
import appeng.api.storage.data.IDisplayRepo;
import appeng.api.storage.data.IItemList;
import appeng.client.gui.AEBaseGui;
import appeng.client.me.ItemRepo;
import appeng.util.item.AEItemStack;
import codechicken.nei.PositionedStack;
import codechicken.nei.api.IOverlayHandler;
import codechicken.nei.recipe.GuiOverlayButton;
import codechicken.nei.recipe.IRecipeHandler;
import codechicken.nei.recipe.StackInfo;

@Mixin(value = IOverlayHandler.class)
public interface MixinIOverlayHandler extends IOverlayHandler {

    @Override
    default List<GuiOverlayButton.ItemOverlayState> presenceOverlay(GuiContainer firstGui, IRecipeHandler recipe,
        int recipeIndex) {
        final List<GuiOverlayButton.ItemOverlayState> itemPresenceSlots = new ArrayList<>();
        final List<PositionedStack> ingredients = recipe.getIngredientStacks(recipeIndex);
        IItemList<IAEStack<?>> list = null;
        boolean displayFluid = false;
        if (AE2ThingAPI.instance()
            .terminal()
            .isTerminal(firstGui)) {
            IDisplayRepo repo = Util.getDisplayRepo((AEBaseGui) firstGui);
            if (repo instanceof ItemRepo) {
                list = Ae2ReflectClient.getList((ItemRepo) repo);
            }
        }
        final List<ItemStack> invStacks = firstGui.inventorySlots.inventorySlots.stream()
            .filter(
                s -> s != null && s.getStack() != null
                    && s.getStack().stackSize > 0
                    && s.isItemValid(s.getStack())
                    && s.canTakeStack(firstGui.mc.thePlayer))
            .map(
                s -> s.getStack()
                    .copy())
            .collect(Collectors.toCollection(ArrayList::new));

        for (PositionedStack stack : ingredients) {
            Optional<ItemStack> used = invStacks.stream()
                .filter(is -> is.stackSize > 0 && stack.contains(is))
                .findAny();
            if (used.isPresent()) {
                ItemStack is = used.get();
                is.stackSize -= 1;
                itemPresenceSlots.add(new GuiOverlayButton.ItemOverlayState(stack, true));
            } else if (list != null) {
                boolean found = false;
                boolean isCraftable = false;
                FluidStack fs = StackInfo.getFluid(stack.item);
                IAEItemStack item;
                if (fs != null) {
                    // [液滴分类] 可迁原生：转液滴仅用于 list.findPrecise 判定配方原料是否在库/可合成(点亮 overlay 按钮),不构造合成请求
                    item = displayFluid ? AEItemStack.create(FluidDropCompat.newDisplayStack(fs))
                        : FluidDropCompat.newAeStack(fs);
                } else {
                    item = AEItemStack.create(stack.item);
                }
                if (list.findPrecise(item) != null) {
                    found = true;
                    isCraftable = list.findPrecise(item)
                        .isCraftable();
                } else if (fs == null) {
                    for (IAEStack<?> is : list.findFuzzy(item, FuzzyMode.IGNORE_ALL)) {
                        if (is instanceof IAEItemStack ais && stack.contains(ais.getItemStack())) {
                            found = true;
                            if (is.isCraftable()) {
                                isCraftable = true;
                                break;
                            }
                        }
                    }
                }
                itemPresenceSlots.add(new AEItemOverlayState(stack, found, isCraftable));
            } else {
                itemPresenceSlots.add(new GuiOverlayButton.ItemOverlayState(stack, false));
            }
        }

        return itemPresenceSlots;
    }
}
